enum ModifyType {
  create(0),
  update(1);

  final int type;
  const ModifyType(this.type);
}
