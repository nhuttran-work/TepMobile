enum GetDataType {
  fetchdata(0),
  loadmore(1);

  final int type;
  const GetDataType(this.type);
}
