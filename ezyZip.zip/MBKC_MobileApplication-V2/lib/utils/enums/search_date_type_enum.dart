enum SearchDateType {
  ordersearch(0),
  transactionsearch(1);

  final int type;
  const SearchDateType(this.type);
}
