// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'category_detail_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$categoryDetailControllerHash() =>
    r'b50938c20cd95d987e6fdb68b89b4fe57934cbec';

/// See also [CategoryDetailController].
@ProviderFor(CategoryDetailController)
final categoryDetailControllerProvider =
    AutoDisposeAsyncNotifierProvider<CategoryDetailController, void>.internal(
  CategoryDetailController.new,
  name: r'categoryDetailControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$categoryDetailControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$CategoryDetailController = AutoDisposeAsyncNotifier<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
