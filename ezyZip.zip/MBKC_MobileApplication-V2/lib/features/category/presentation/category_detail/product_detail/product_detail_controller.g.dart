// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'product_detail_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$productDetailControllerHash() =>
    r'c9da35cb83bd471f8512c32ce6bde6692dde60a7';

/// See also [ProductDetailController].
@ProviderFor(ProductDetailController)
final productDetailControllerProvider =
    AutoDisposeAsyncNotifierProvider<ProductDetailController, void>.internal(
  ProductDetailController.new,
  name: r'productDetailControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$productDetailControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$ProductDetailController = AutoDisposeAsyncNotifier<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
