// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'money_exchange_repository.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$moneyExchangeRepositoryHash() =>
    r'205a6bba6cc97570f39784cf7847d0784e265f4f';

/// See also [moneyExchangeRepository].
@ProviderFor(moneyExchangeRepository)
final moneyExchangeRepositoryProvider =
    Provider<MoneyExchangeRepository>.internal(
  moneyExchangeRepository,
  name: r'moneyExchangeRepositoryProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$moneyExchangeRepositoryHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef MoneyExchangeRepositoryRef = ProviderRef<MoneyExchangeRepository>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
