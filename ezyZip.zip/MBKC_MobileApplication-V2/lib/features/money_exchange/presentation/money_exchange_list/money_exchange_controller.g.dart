// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'money_exchange_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$moneyExchangeControllerHash() =>
    r'4393f550234455ccb99d08d677e9a506ccd2dc65';

/// See also [MoneyExchangeController].
@ProviderFor(MoneyExchangeController)
final moneyExchangeControllerProvider =
    AutoDisposeAsyncNotifierProvider<MoneyExchangeController, void>.internal(
  MoneyExchangeController.new,
  name: r'moneyExchangeControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$moneyExchangeControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$MoneyExchangeController = AutoDisposeAsyncNotifier<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
