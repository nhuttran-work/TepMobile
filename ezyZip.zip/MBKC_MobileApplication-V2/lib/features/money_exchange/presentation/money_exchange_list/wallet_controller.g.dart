// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'wallet_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$walletControllerHash() => r'31809932e21dd6c881f72a1441fdb46508473e76';

/// See also [WalletController].
@ProviderFor(WalletController)
final walletControllerProvider =
    AutoDisposeAsyncNotifierProvider<WalletController, void>.internal(
  WalletController.new,
  name: r'walletControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$walletControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$WalletController = AutoDisposeAsyncNotifier<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
