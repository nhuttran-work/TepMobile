// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'change_password_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$changePasswordControllerHash() =>
    r'c1900f889b387480ca615f081da7cc11a28d65aa';

/// See also [ChangePasswordController].
@ProviderFor(ChangePasswordController)
final changePasswordControllerProvider =
    AutoDisposeAsyncNotifierProvider<ChangePasswordController, void>.internal(
  ChangePasswordController.new,
  name: r'changePasswordControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$changePasswordControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$ChangePasswordController = AutoDisposeAsyncNotifier<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
