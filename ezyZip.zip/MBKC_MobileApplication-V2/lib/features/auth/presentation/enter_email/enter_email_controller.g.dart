// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'enter_email_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$enterEmailControllerHash() =>
    r'0248f8867b99a4254f605bd4e94d1a111b4daab5';

/// See also [EnterEmailController].
@ProviderFor(EnterEmailController)
final enterEmailControllerProvider =
    AutoDisposeAsyncNotifierProvider<EnterEmailController, void>.internal(
  EnterEmailController.new,
  name: r'enterEmailControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$enterEmailControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$EnterEmailController = AutoDisposeAsyncNotifier<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
