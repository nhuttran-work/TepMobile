// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'otp_verification_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$otpVerificationControllerHash() =>
    r'bd68f7393f508a2d474ece2663fcdba1b5adce47';

/// See also [OtpVerificationController].
@ProviderFor(OtpVerificationController)
final otpVerificationControllerProvider =
    AutoDisposeAsyncNotifierProvider<OtpVerificationController, void>.internal(
  OtpVerificationController.new,
  name: r'otpVerificationControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$otpVerificationControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$OtpVerificationController = AutoDisposeAsyncNotifier<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
