// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'modify_order_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$modifyOrderControllerHash() =>
    r'1a85e2bf2ec9e1d96aebe81243511769998a2799';

/// See also [ModifyOrderController].
@ProviderFor(ModifyOrderController)
final modifyOrderControllerProvider =
    AutoDisposeAsyncNotifierProvider<ModifyOrderController, void>.internal(
  ModifyOrderController.new,
  name: r'modifyOrderControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$modifyOrderControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$ModifyOrderController = AutoDisposeAsyncNotifier<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
