// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'order_detail_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$orderDetailControllerHash() =>
    r'b061ce9338931ffb54e562a34a881434dec67b24';

/// See also [OrderDetailController].
@ProviderFor(OrderDetailController)
final orderDetailControllerProvider =
    AutoDisposeAsyncNotifierProvider<OrderDetailController, void>.internal(
  OrderDetailController.new,
  name: r'orderDetailControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$orderDetailControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$OrderDetailController = AutoDisposeAsyncNotifier<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
