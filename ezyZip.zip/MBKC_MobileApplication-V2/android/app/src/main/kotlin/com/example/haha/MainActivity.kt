package com.example.haha

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
