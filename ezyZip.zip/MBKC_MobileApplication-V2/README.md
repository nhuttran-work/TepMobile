# MBKC Mobile Application

MBKC Mobile Application with Flutter, Firebase & Riverpod 2.0!

## Tech Used
**Server**: C#, Firebase Storage, Fibase Cloud Messaging
**Client**: Flutter, Riverpod

<p align="center">
  <img width="600" src="https://firebasestorage.googleapis.com/v0/b/mbkc-image-e6026.appspot.com/o/system-images%2FMBKC-logo.png?alt=media&token=12392b1d-ff4f-4db2-9c48-a4d545adeb83" alt="MBKC Logo">
</p>

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://docs.flutter.dev/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://docs.flutter.dev/cookbook)

For help getting started with Flutter development, view the
[online documentation](https://docs.flutter.dev/), which offers tutorials,
samples, guidance on mobile development, and a full API reference.
